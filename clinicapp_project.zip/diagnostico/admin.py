from django.contrib import admin
from .models import Diagnostico, Repuesto

admin.site.register(Repuesto)
admin.site.register(Diagnostico)
