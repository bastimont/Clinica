from django.db import models
from django.contrib.auth import get_user_model

class Cliente(models.Model):
    nombre = models.CharField(max_length=200)
    correo = models.EmailField(blank=True, null=True)
    telefono = models.CharField(max_length=20, blank=True)

    def __str__(self):
        return self.nombre

class Equipo(models.Model):
    cliente = models.ForeignKey(Cliente, on_delete=models.CASCADE, related_name='equipos')
    marca = models.CharField(max_length=100)
    modelo = models.CharField(max_length=100, blank=True)
    serial = models.CharField(max_length=200, blank=True)

    def __str__(self):
        return f"{self.marca} {self.modelo} ({self.serial})"

class Recepcion(models.Model):
    ESTADO_CHOICES = [
        ('INGRESADO','Ingresado'),
        ('EN_DIAGNOSTICO','En diagnóstico'),
        ('REPARACION','En reparación'),
        ('LISTO','Listo para entrega'),
    ]
    equipo = models.ForeignKey(Equipo, on_delete=models.CASCADE, related_name='recepciones')
    fecha_ingreso = models.DateTimeField(auto_now_add=True)
    problema_reportado = models.TextField()
    estado = models.CharField(max_length=20, choices=ESTADO_CHOICES, default='INGRESADO')
    recibido_por = models.ForeignKey(get_user_model(), on_delete=models.SET_NULL, null=True, blank=True)

    def __str__(self):
        return f"Recepción #{self.id} - {self.equipo}"
