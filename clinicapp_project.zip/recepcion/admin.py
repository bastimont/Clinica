from django.contrib import admin
from .models import Cliente, Equipo, Recepcion

@admin.register(Cliente)
class ClienteAdmin(admin.ModelAdmin):
    list_display = ('nombre','correo','telefono')

@admin.register(Equipo)
class EquipoAdmin(admin.ModelAdmin):
    list_display = ('marca','modelo','serial','cliente')
    search_fields = ('marca','modelo','serial')

@admin.register(Recepcion)
class RecepcionAdmin(admin.ModelAdmin):
    list_display = ('id','equipo','fecha_ingreso','estado','recibido_por')
    list_filter = ('estado','fecha_ingreso')
    search_fields = ('equipo__serial','equipo__marca')
