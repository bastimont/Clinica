from django.contrib import admin
from .models import Entrega

admin.site.register(Entrega)
