from django.db import models
from diagnostico.models import Diagnostico

class Entrega(models.Model):
    diagnostico = models.OneToOneField(Diagnostico, on_delete=models.CASCADE, related_name='entrega')
    fecha_entrega = models.DateTimeField(null=True, blank=True)
    entregado_por = models.CharField(max_length=200)
    recibido_por = models.CharField(max_length=200)
    observaciones = models.TextField(blank=True)

    def __str__(self):
        return f"Entrega #{self.id} - Diagnóstico {self.diagnostico.id}"
