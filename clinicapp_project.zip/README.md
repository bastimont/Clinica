# Clínica del PC - Proyecto Django (esqueleto)

Generado automáticamente — incluye estructura base exigida por la rúbrica.

## Requisitos
- Python 3.13.5 (según lo indicado)
- PostgreSQL (local o contenedor)
- Virtualenv

## Cómo usar (local)
1. Crear y activar entorno virtual:
```bash
python -m venv venv
# Windows
venv\Scripts\activate
# Linux / macOS
source venv/bin/activate
```
2. Instalar dependencias:
```bash
pip install -r requirements.txt
```
3. Copiar `.env.example` a `.env` y editar valores (DB_NAME, DB_USER, DB_PASS, DB_HOST, DB_PORT, SECRET_KEY).
4. Migraciones y superuser:
```bash
python manage.py makemigrations
python manage.py migrate
python manage.py createsuperuser
```
5. Ejecutar servidor:
```bash
python manage.py runserver
```

## Estructura incluida
- 4 apps: login, recepcion, diagnostico, entrega
- settings con django-environ (.env.example)
- modelos de ejemplo (1:1, 1:N, N:M)
- admin registrado
- templates básicos y página home con menú

Sigue la guía original para completar y personalizar vistas, permisos y estilos.
