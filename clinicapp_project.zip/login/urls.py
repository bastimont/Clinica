from django.urls import path
from .views import UserLoginView, index

app_name = 'login'
urlpatterns = [
    path('', index, name='index'),
    path('entrar/', UserLoginView.as_view(), name='entrar'),
]
